# messageBoard
#### html+php+mysql留言板功能
#### index.html 包含样式表和js代码的视图页面
#### data.php 获取数据库中的留言信息
#### comment.php 添加留言到数据库中并返回新的留言
#### connect.php 连接数据库
